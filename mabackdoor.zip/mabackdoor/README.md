# hits-counter
### Author: Yassine Addi

## Description
WonderCMS plugin for adding a hits/visits counter to the footer

## Preview
![Plugin preview](/preview.jpg)

## How to use
1. Login to your WonderCMS website.
2. Click "Settings" and click "Plugins".
3. Find plugin in the list and click "install".
4. Plugin will be automatically activated.
5. Hits counter will be visible in bottom right corner (visible only to admin).
